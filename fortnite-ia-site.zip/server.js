require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "frontend")));

const systemInstruction = `Tu es Fortnite IA, un assistant francophone non officiel consacré à Fortnite.
Réponds clairement et utilement sur les stratégies, modes, mécaniques, paramètres, construction, entraînement et actualités connues.
N'invente pas les nouveautés en direct : précise quand une information peut avoir changé.
Tu n'es pas affilié à Epic Games. Ne demande jamais de mot de passe, code de connexion ou données personnelles.
Si une question sort de Fortnite, tu peux aider brièvement puis ramener la conversation au jeu.`;

function demoAnswer(message) {
  const m = message.toLowerCase();
  if (m.includes("constru") || m.includes("build")) {
    return "Pour progresser en construction :\\n1. Entraîne-toi à enchaîner mur, sol, rampe et toit.\\n2. Répète les mêmes mouvements en créatif jusqu’à ce qu’ils deviennent automatiques.\\n3. Travaille aussi le placement et la visée : construire vite ne sert pas à grand-chose si tu rates tous tes tirs.\\n\\nMode démo : ajoute une clé Gemini pour activer les réponses IA personnalisées.";
  }
  if (m.includes("viser") || m.includes("aim") || m.includes("visée")) {
    return "Pour améliorer ta visée, garde une sensibilité confortable, échauffe-toi quelques minutes dans une carte d’entraînement et privilégie la précision plutôt que les mouvements brusques. Change un seul réglage à la fois et teste-le plusieurs parties.\\n\\nMode démo : ajoute une clé Gemini pour activer les réponses IA personnalisées.";
  }
  return "Salut ! 👋 Je suis Fortnite IA, ton assistant non officiel pour Fortnite. Je peux t’aider avec les stratégies, la construction, les réglages et l’entraînement.\\n\\nLe mode démo est actif : ajoute une clé API Gemini dans le fichier .env pour recevoir des réponses générées par l’IA.";
}

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body.message === "string" ? req.body.message.trim() : "";
    const history = Array.isArray(req.body.history) ? req.body.history.slice(-10) : [];
    if (!message) return res.status(400).json({ error: "Écris une question avant d’envoyer." });
    if (message.length > 2000) return res.status(400).json({ error: "Ta question est trop longue (maximum 2 000 caractères)." });

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "colle_ta_cle_ici") {
      return res.json({ reply: demoAnswer(message), demo: true });
    }

    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      contents.push({ role: item.role, parts: [{ text: item.text.slice(0, 2000) }] });
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + encodeURIComponent(apiKey),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemInstruction }] },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error:", data.error?.message || response.status);
      return res.status(502).json({ error: "L’IA n’a pas répondu. Vérifie la clé API et les quotas dans la console du fournisseur." });
    }
    const reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!reply) return res.status(502).json({ error: "L’IA a renvoyé une réponse vide. Réessaie." });
    res.json({ reply, demo: false });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Erreur serveur. Réessaie dans un instant." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "frontend", "index.html")));
app.listen(PORT, () => console.log(`Fortnite IA prêt sur http://localhost:${PORT}`));