const form = document.querySelector("#chat-form");
const input = document.querySelector("#question");
const messages = document.querySelector("#messages");
const sendButton = document.querySelector("#send");
const typing = document.querySelector("#typing");
const modeLabel = document.querySelector("#mode-label");
const history = [];
document.querySelector("#year").textContent = new Date().getFullYear();

function addMessage(role, text) {
  const article = document.createElement("article");
  article.className = `message ${role}`;
  if (role === "assistant") {
    const avatar = document.createElement("span");
    avatar.className = "mini-avatar";
    avatar.textContent = "✦";
    article.appendChild(avatar);
  }
  const body = document.createElement("div");
  const label = document.createElement("small");
  label.textContent = role === "user" ? "TOI" : "FORTNITE IA";
  const p = document.createElement("p");
  p.textContent = text;
  body.append(label, p);
  article.appendChild(body);
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
}

async function sendMessage(text) {
  const clean = text.trim();
  if (!clean || sendButton.disabled) return;
  addMessage("user", clean);
  input.value = "";
  input.style.height = "auto";
  sendButton.disabled = true;
  typing.hidden = false;
  messages.scrollTop = messages.scrollHeight;
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: clean, history })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Une erreur est survenue.");
    addMessage("assistant", data.reply);
    history.push({ role: "user", text: clean }, { role: "model", text: data.reply });
    while (history.length > 10) history.shift();
    modeLabel.textContent = data.demo ? "MODE DÉMO · AJOUTE UNE CLÉ API POUR L’IA" : "IA PERSONNALISÉE ACTIVE";
  } catch (err) {
    addMessage("assistant", `Petit problème technique : ${err.message}`);
  } finally {
    typing.hidden = true;
    sendButton.disabled = false;
    input.focus();
  }
}
form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});
input.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    form.requestSubmit();
  }
});
input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 120) + "px";
});
document.querySelectorAll("[data-question]").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.question;
    document.querySelector("#chat").scrollIntoView({ behavior: "smooth" });
    sendMessage(input.value);
  });
});