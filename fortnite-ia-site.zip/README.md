# Fortnite IA

Site web responsive avec un assistant de questions/réponses sur Fortnite, un design gaming néon et une intégration Gemini côté serveur.

> Projet de fan non officiel. Non affilié à Epic Games. Fortnite est une marque de ses propriétaires respectifs.

## Prérequis
- Node.js 18 ou plus récent
- Une clé API Gemini (facultative pour tester le mode démo)

## Lancer sur ton ordinateur
1. Décompresse le dossier.
2. Installe Node.js depuis https://nodejs.org/
3. Ouvre un terminal dans le dossier `fortnite-ia`.
4. Lance `npm install`.
5. Copie `.env.example` vers `.env`.
6. Pour l'IA réelle, crée une clé sur https://aistudio.google.com/ et colle-la dans `.env` après `GEMINI_API_KEY=`.
7. Lance `npm start`.
8. Ouvre http://localhost:3000 dans ton navigateur.

Sans clé API, le site démarre en mode démo. Pour de vraies réponses, la clé reste sur le serveur et n'est jamais envoyée au navigateur.

## Mise en ligne gratuite (Render)
1. Crée un dépôt GitHub et téléverse les fichiers du projet, sans le fichier `.env`.
2. Sur https://render.com/, crée un **Web Service** connecté à ce dépôt.
3. Choisis l'environnement **Node**, la commande de build `npm install` et la commande de lancement `npm start`.
4. Dans **Environment Variables**, ajoute `GEMINI_API_KEY` avec ta clé.
5. Déploie le service et ouvre l'URL fournie.

Les offres gratuites et leurs limites peuvent changer. Le service d'hébergement et l'API IA peuvent avoir des quotas, restrictions ou coûts selon leur politique du moment. Ne publie jamais ta clé API dans GitHub ni dans le code du navigateur.

## Personnalisation
- Textes et structure : `frontend/index.html`
- Couleurs et mise en page : `frontend/style.css`
- Comportement du chat : `frontend/script.js`
- Instructions et modèle IA : `server.js`

## Sécurité et limites
- Le serveur limite les questions à 2 000 caractères et n'envoie que les 10 derniers messages d'historique.
- Pour un site public, ajoute de la limitation de débit (rate limiting), une politique de confidentialité et une protection contre l'abus avant de partager largement l'URL.
- Ne demande pas aux visiteurs leurs mots de passe ou codes de connexion Epic Games.
